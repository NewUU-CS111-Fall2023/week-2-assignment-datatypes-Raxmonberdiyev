/*
 * Author: Raximberdi
 * Date:10/25/2023
 */  //problem1 with solution by class

#include <iostream>
#include "task_1.h"
using namespace std;
int main() {
    Leap L;
    int y;
    cout << "Enter Year: ";
    cin >> y;
    L.leapYear(y);
    return 0;
}





