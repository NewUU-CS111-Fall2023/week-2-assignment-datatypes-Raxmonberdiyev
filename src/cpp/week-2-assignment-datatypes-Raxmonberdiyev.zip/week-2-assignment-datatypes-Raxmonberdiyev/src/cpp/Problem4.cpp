/*
 * Author: Raximberdi
 * Date:10/25/2023
 */

#include <iostream>
using namespace std;

int main() {
    string s, subS;
    cin >> s >> subS;
    string anser = "";
    for (int i = 0; i < s.size(); i++) {
        if (s.substr(i, subS.size()) == subS) {
            anser += s.substr(i, subS.size());
        }
    }
    if (anser == "") {
        cout << "It is not match" << endl;
    } else {
        cout << anser << endl;
    }
    return 0;
}




