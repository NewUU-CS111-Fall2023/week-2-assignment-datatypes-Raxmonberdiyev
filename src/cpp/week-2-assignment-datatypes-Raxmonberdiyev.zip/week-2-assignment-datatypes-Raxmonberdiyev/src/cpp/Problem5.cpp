/*
 * Author: Raximberdi
 * Date:10/25/2023
 */
#include <bits/stdc++.h>
#include <iostream>
#include <string>
using namespace std;

int main() {
    int num, x, y, x1, y1;
    vector<pair<int, int>> coordinates;
    cout<<"Enter a number"<<endl;
    cin >> num;

    for (int i = 0; i < num; i++) {
        cin >> x >> y;
        coordinates.push_back(make_pair(x, y));
    }

    for (int j = 0; j < num; j++) {
        cin >> x1 >> y1;
        if (x1 == coordinates[j].first && y1 == coordinates[j].second) {
            cout << "You died" << endl;
        } else {
            cout << "You are alive" << endl;
        }
    }
}
