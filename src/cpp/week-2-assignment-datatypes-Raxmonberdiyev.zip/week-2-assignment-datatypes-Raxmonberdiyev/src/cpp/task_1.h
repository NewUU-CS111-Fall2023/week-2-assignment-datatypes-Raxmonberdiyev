/*
 * Author: Rximberdi
 * Date:  10/25/23
 * Name:
 */
using namespace std;
#include <iostream>
class Leap {
private:
    int year;
public:
    void leapYear(int y) {
        year = y;

        if (year % 400 == 0) {
            cout << year << " is a leap year.";
        }

        else if (year % 100 == 0) {
            cout << year << " is not a leap year.";
        }

        else if (year % 4 == 0) {
            cout << year << " is a leap year.";
        }

        else {
            cout << year << " is not a leap year.";
        }
    };
};

