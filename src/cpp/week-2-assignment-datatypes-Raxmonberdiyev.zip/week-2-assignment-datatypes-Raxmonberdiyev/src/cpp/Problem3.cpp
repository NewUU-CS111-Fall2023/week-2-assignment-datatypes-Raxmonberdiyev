/*
 * Author: Raximberdi
 * Date:10/25/2023
 */

#include <iostream>
#include <string>
using namespace std;

int main() {
    string num = "1";
    for (int i = 0; i < 99; i++) {
        num += "0";
    }
    int A;
    cout << "Enter a number A: ";
    cin >> A;
    string quotient = "";
    int remainder = 0;
    for (int i = 0; i < 100; i++) {
        int digit = num[i] - '0';
        digit += remainder * 10;
        remainder = digit % A;
        quotient += to_string(digit / A);
    }
    cout << "Result: " << quotient << endl;
    return 0;
}





