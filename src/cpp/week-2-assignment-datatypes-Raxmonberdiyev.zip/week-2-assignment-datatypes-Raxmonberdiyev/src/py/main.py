# * Author: Raximberdi
# * Date: 10/25/2023
# * Problem2  Guess number funcsion
import random
n = random.randrange(1,100)
guess = int(input("Enter any number: "))
while n!= guess:
    if guess < n:
        print("Too low")
        guess = int(input("Enter number again: "))
    elif guess > n:
        print("Too high! Try again")
        guess = int(input("Enter number again: "))
    else:
      break
print("You guessed it right!! Barakalla")